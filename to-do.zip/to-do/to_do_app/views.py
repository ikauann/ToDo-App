from django.http import HttpResponse
from django.shortcuts import render
from .models import ToDo

def index(request):
     task = ToDo.objects.order_by('-task_name')

     for post in request.POST.keys():
          if post == "to-do-search":
               search = request.POST.get('to-do-search')
               ToDo.objects.create(task_name=search)
               task = ToDo.objects.order_by('-task_name')
               
          if post == "deletar":
               item = request.POST.get('deletar')
               ToDo.objects.filter(task_name=item).delete()
          
     return render(request, 'to_do_app/index.html', {'task':task})
